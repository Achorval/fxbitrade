<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper">
    <div class="container-full">
        <div class="content-header">
            <h3><?php echo e($user->username); ?> Active Deposits</h3>
        </div> 
        <section class="content">
            <div class="row">	
                <div class="col-12">
                    <div class="box">
                        <div class="box-body p-15">						
                            <div class="table-responsive">
                                <table id="tickets" class="table mt-0 table-hover no-wrap table-bordered" data-page-size="10">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Amount</th>
                                            <th colspan="2" rowspan="1">Currency</th>
                                            <th>Reference</th>
                                            <th>Description</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $sn = 1 ?>
                                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($sn++); ?></td>
                                            <td>$<?php echo e($transaction->amount); ?></td>
                                            <td>
                                                <div style="width: 24px;height:24px">
                                                    <?= $transaction->currency->image  ?>
                                                </div>
                                            </td>
                                            <td>
                                                <small>
                                                    <a href="#" class="hover-warning"> 
                                                    <?php echo e($transaction->currency->name); ?></a>
                                                </small>
                                                <h6 class="text-muted">BTC</h6>
                                            </td>
                                            <td><?php echo e($transaction->reference); ?></td>
                                            <td><?php echo e($transaction->description); ?></td>
                                            <td>
                                                <?php if($transaction->status->name == "Successful"): ?>
                                                <span class="badge badge-success">
                                                    <?php echo e($transaction->status->name); ?>

                                                </span> 
                                                <?php elseif($transaction->status->name == "Canceled"): ?>
                                                    <span class="badge badge-danger">
                                                        <?php echo e($transaction->status->name); ?>    
                                                    </span> 
                                                <?php else: ?>
                                                    <span class="badge badge-warning">
                                                        <?php echo e($transaction->status->name); ?>    
                                                    </span> 
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary shadow btn-xs sharp mr-1 processDeposit" data-user_id="<?php echo e($user->id); ?>" data-id="<?php echo e($transaction->id); ?>" >Process</button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projects/fxbitrade/resources/views/admin/history/activeDeposits.blade.php ENDPATH**/ ?>
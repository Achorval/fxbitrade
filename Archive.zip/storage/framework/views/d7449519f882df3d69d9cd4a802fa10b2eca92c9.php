<aside class="main-sidebar">
    <section class="sidebar">	
        <div class="user-profile">
            <div class="ulogo">
                <a href="<?php echo e(route('user')); ?>">
                <h3><b>Fx</b>Bitrade</h3>
                </a>
            </div>
        </div>
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header nav-small-cap">PERSONAL</li>
            <li class="<?php echo e(Request::is('user/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('user')); ?>">
                    <i class="ti-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="header nav-small-cap">Services</li>	
            <li class="<?php echo e(Request::is('user/deposit') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('deposit')); ?>">
                    <i class="glyphicon glyphicon-transfer"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('user/withdraw') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('withdraw')); ?>">
                    <i class="glyphicon glyphicon-save"></i>
                    <span>Withdraw</span>
                </a>
            </li> 
            <li class="<?php echo e(Request::is('user/transactions') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('transactionHistory')); ?>">
                    <i class="ti-list"></i>
                    <span>Transactions</span>
                </a>
            </li>  
            <li class="header nav-small-cap">Account</li>	
            <li class="<?php echo e(Request::is('user/settings/referrals') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('userReferrals')); ?>">
                    <i class="ti-reload"></i>
                    <span>Referrals</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('user/settings/profile') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('userProfile')); ?>">
                    <i class="ti-settings"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="header nav-small-cap">ACTION</li>	
            <li>
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="ti-power-off"></i>
                    <span>Log Out</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li> 
        </ul>
    </section>
</aside><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projects/fxbitrade/resources/views/user/layouts/sidebar.blade.php ENDPATH**/ ?>
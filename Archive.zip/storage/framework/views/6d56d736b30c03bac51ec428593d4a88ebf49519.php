<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper"> 
    <div class="container-full">
        <section class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">User Details</h4>
                        </div>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-wrap table-bordered" style="width: 100%">
                                    <tbody>
                                        <tr>
                                            <table class="table table-hover table-bordered" style="width: 100%">
                                                <tbody>
                                                    <tr><th style="width: 45%">Username:</th><td  style="width: 55%"><?php echo e($user->username); ?></td></tr>
                                                    <tr><th style="width: 45%">Full Name:</th><td style="width: 55%"><?php echo e($user->name); ?></td></tr>
                                                    <tr><th>E-mail:</th><td><?php echo e($user->email); ?></td></tr>
                                                </tbody>
                                            </table>
                                            
                                            <table class="table table-hover table-bordered" style="width: 100%">
                                                <tbody>
                                                    <tr>
                                                        <th style="width: 45%">Total Balance:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($balance->current); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Total Deposit:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($totalDeposit); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Active Deposit:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($ActiveDeposit); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="<?php echo e(route('activeDeposits', ['id'=>$user->id])); ?>" class="btn btn-danger btn-xs">
                                                                    Manage Deposit
                                                                </a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Total Earning:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($totalEarning); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Total Withdrawal:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($totalWithdrawal); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Pending Withdrawals:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($pendingWithdrawal); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Total Bonus:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($totalBonus); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions/user/<?php echo e($user->id); ?>" class="btn btn-danger btn-xs">
                                                                Add a Bonus</a>
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                    History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 45%">Referral Commissions:</th>
                                                        <td style="width: 55%">
                                                            $<?php echo e($referralCommission); ?>

                                                            <div class="d-inline float-right">
                                                                <a href="/admin/transactions" class="btn btn-primary btn-xs">
                                                                History</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>							
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projects/fxbitrade/resources/views/admin/main/details.blade.php ENDPATH**/ ?>
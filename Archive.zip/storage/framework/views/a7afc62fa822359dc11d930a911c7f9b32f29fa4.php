<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper"> 
    <div class="container-full">
        <section class="content">
            <div class="row">
                <div class="col-md-7">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title">Add a Transaction</h4>
                        </div>
                        <div class="box-body">
                            <form class="addTransactionForm" action="<?php echo e(route('createAddTransaction', ['id'=>$user->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="table-responsive">
                                    <table class="table no-wrap table-bordered" style="width: 100%">
                                        <tbody>
                                            <tr>
                                                <table class="table table-hover table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="emailAddress1">User :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <a href="<?php echo e(route('userDetails', ['id'=>$user->id])); ?>"><?php echo e($user->username); ?></a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="emailAddress1">Payment Method :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <select name="currency" id="currency" class="form-control" aria-invalid="false">
                                                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                                </select>
                                                                <span class="invalid-feedback animated fadeInUp currency-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="amount">Amount ($) :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <input type="number" class="form-control" name="amount" id="amount" placeholder="Amount"> 
                                                                <span class="invalid-feedback animated fadeInUp amount-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="type">Transaction Type :</label></th>
                                                            <td style="width: 70%">
                                                                <select name="type" id="type" class="form-control" aria-invalid="false">
                                                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>    
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                                </select>
                                                                <span class="invalid-feedback animated fadeInUp type-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="emailAddress1">Description :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <input type="text" class="form-control" name="description" id="description" placeholder="Description"> 
                                                                <span class="invalid-feedback animated fadeInUp description-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="deposit">Deposit the Bonus :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <select name="deposit" id="deposit" class="form-control" aria-invalid="false">
                                                                    <option value="0">-- Not Deposit --</option>
                                                                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->percent); ?>% profit after <?php echo e($plan->duration); ?></option> 
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <span class="invalid-feedback animated fadeInUp bonus-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="referral">Add Referral Commission :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <select name="referral" id="referral" class="form-control" aria-invalid="false">
                                                                    <option value="1">Yes</option>
                                                                    <option value="0">No</option> 
                                                                </select>
                                                                <span class="invalid-feedback animated fadeInUp referral-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="width: 30%">
                                                                <label for="email">Send Email Notification :</label>
                                                            </th>
                                                            <td style="width: 70%">
                                                                <select name="email" id="email" class="form-control" aria-invalid="false">
                                                                    <option value="1">Yes</option>
                                                                    <option value="0">No</option> 
                                                                </select>
                                                                <span class="invalid-feedback animated fadeInUp email-feedback" style="display: block;">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table no-wrap table-bordered" style="width: 100%">
                                        <tr>
                                            <table class="table table-hover table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <th style="width: 40%">
                                                            <label for="password">Admin Alternative Passphrase:</label>
                                                        </th>
                                                        <td style="width: 60%">
                                                            <input type="password" class="form-control" name="password" id="password" placeholder="Password"> 
                                                        </td>
                                                        <span class="invalid-feedback animated fadeInUp password-feedback" style="display: block;">
                                                        </span>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </tr>
                                    </table>
                                    <div class="form-group mt-3">
                                        <button type="submit" class="waves-effect waves-light btn btn-primary my-10 d-block w-p100 d-flex align-items-center justify-content-center">Send Transaction</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>							
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projects/fxbitrade/resources/views/admin/history/addTransaction.blade.php ENDPATH**/ ?>
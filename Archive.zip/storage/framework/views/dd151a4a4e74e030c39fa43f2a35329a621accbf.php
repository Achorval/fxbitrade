<aside class="main-sidebar">
    <section class="sidebar">	
        <div class="user-profile">
            <div class="ulogo">
                <a href="<?php echo e(route('admin')); ?>">
                    <h3><b>Fx</b>Bitrade</h3>
                </a>
            </div>
        </div>
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header nav-small-cap">MAIN</li>
            <li class="<?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin')); ?>">
                    <i class="ti-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('admin/users') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('users')); ?>">
                    <i class="ti-user"></i>
                    <span>Users</span>
                </a>
            </li> 
            <li class="<?php echo e(Request::is('admin/transactions') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('transactions')); ?>">
                    <i class="ti-list"></i>
                    <span>Transactions</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('admin/withdrawal_requests') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('withdrawalRequests')); ?>">
                    <i class="ti-list"></i>
                    <span>Withdrawal Requests</span>
                </a>
            </li> 
            <li class="header nav-small-cap">SYSTEM</li>	
            <li class="<?php echo e(Request::is('admin/currencies') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('currencies')); ?>">
                    <i class="ti-money"></i>
                    <span>Currency</span>
                </a>
            </li> 
            <li class="<?php echo e(Request::is('admin/plans') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('adminPlans')); ?>">
                    <i class="ti-view-list"></i>
                    <span>Plans</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('admin/profile') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('adminProfile')); ?>">
                    <i class="ti-settings"></i>
                    <span>Settings</span>
                </a>
            </li>            
            <li class="header nav-small-cap">ACTION</li>		  
            <li>
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="ti-power-off"></i>
                    <span>Log Out</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li> 
        </ul>
    </section>
</aside><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projects/fxbitrade/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>